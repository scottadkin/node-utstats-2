import Countires from '../../api/countries';

const CountryFlag = ({country}) =>{

    let flag = Countires(country);

    return (<img className="country-flag" src={`/images/flags/${flag.code.toLowerCase()}.svg`} alt="flag"/>);
}


export default CountryFlag;