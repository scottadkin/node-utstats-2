import Link from 'next/link';
import TimeStamp from '../TimeStamp/';
import MMSS from '../MMSS/';
import MatchResultSmall from '../MatchResultSmall/';
import React from 'react';

class MatchesTableView extends React.Component{

    constructor(props){
        super(props);
    }


    createRows(matches){

        const rows = [];    

        let m = 0;

        let url = "";


        for(let i = 0; i < matches.length; i++){

            m = matches[i];

            url = `/match/${m.id}`;

            // <td><Link href={url}><a>{m.serverName}</a></Link></td>
            rows.push(<tr key={`matches-row-${i}`}>
               
                <td><Link href={url}><a><TimeStamp timestamp={m.date} noDayName={true}/></a></Link></td>
                <td><Link href={url}><a>{m.gametypeName}</a></Link></td>
                <td><Link href={url}><a>{m.mapName}</a></Link></td>
                <td><Link href={url}><a>{m.players}</a></Link></td>
                <td><Link href={url}><a><MMSS timestamp={m.playtime} /></a></Link></td>
                <td className="padding-0"><MatchResultSmall 
                    totalTeams={m.total_teams} 
                    dmWinner={m.dm_winner} 
                    dmScore={m.dm_score} 
                    redScore={Math.floor(m.team_score_0)}
                    blueScore={Math.floor(m.team_score_1)}
                    greenScore={Math.floor(m.team_score_2)}
                    yellowScore={Math.floor(m.team_score_3)}
                    bMonsterHunt={m.mh}
                    endReason={m.end_type}
                    />
                </td>
            </tr>);

        }

        return rows;
    }

    render(){

        const matches = JSON.parse(this.props.data);

        const rows = this.createRows(matches);


        if(matches.length === 0){
            return null;//;(<div className="not-found">There are no matches meeting your search requirements.</div>);
        }


        return (
            <div className="center">
                <table className="t-width-1">
                    <tbody>
                        <tr>
                            <th>Date</th>
                            <th>Gametype</th>
                            <th>Map</th>               
                            <th>Players</th>
                            <th>Playtime</th>
                            <th>Result</th>
                        </tr>
                        {rows}
                    </tbody>
                </table>
            </div>
        );
    }
}


export default MatchesTableView;