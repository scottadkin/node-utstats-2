const mysql = require('./database');
const Promise = require('promise');
const Message = require('./message');
const fs = require('fs');

class Assault{

    constructor(){

    }

    exists(map, name, objId){

        return new Promise((resolve, reject) =>{

            const query = "SELECT COUNT(*) as total_objs FROM nstats_assault_objects WHERE map=? AND name=? and obj_id=?";

            mysql.query(query, [map, name, objId], (err, result) =>{

                if(err) reject(err);

                if(result[0].total_objs > 0){
                    resolve(true);
                }

                resolve(false);
            });

        });
    }

    createMapObjective(map, name, objId){

        return new Promise((resolve, reject) =>{

            const query = "INSERT INTO nstats_assault_objects VALUES(NULL,?,0,?,?,0,0)";

            mysql.query(query, [map, name, objId], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });
    }


    async updateMapObjective(map, name, objId){

        try{

            if(await this.exists(map, name, objId)){

                new Message(`Assault Objective "${name}" with map id of ${objId} for map ${map} exists.`,'pass');

            }else{

                new Message(`An assault objective on map ${map} with the name of ${name} objId ${objId} does not exist, creating.`,'note');
                await this.createMapObjective(map, name, objId);
                new Message(`Obective "${name}" for map ${map} has been added to the database.`,'pass');
            }

        }catch(err){
            new Message(`Failed to addMapObjective ${err}`,'error');
        }
    }

    insertObjectiveCapture(matchId, mapId, timestamp, objId, player, bFinal){

        return new Promise((resolve, reject) =>{

            const query = "INSERT INTO nstats_assault_match_objectives VALUES(NULL,?,?,?,?,?,?)";

            mysql.query(query, [matchId, mapId, timestamp, objId, player, bFinal], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });
    }

    updateMapCaptureTotals(map, objId, taken){

        return new Promise((resolve, reject) =>{

            const query = "UPDATE nstats_assault_objects SET matches=matches+1, taken=taken+? WHERE map=? AND obj_id=?";

            mysql.query(query, [taken, map, objId], (err) =>{

                if(err) reject(err);

                resolve();

            });
        });

    }

    updatePlayerCaptureTotals(taken, masterId, gametypeId){

        return new Promise((resolve, reject) =>{

            const query = "UPDATE nstats_player_totals SET assault_objectives=assault_objectives+? WHERE id IN(?,?)";

            mysql.query(query, [taken, masterId, gametypeId], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });
    }


    setAttackingTeam(matchId, team){

        return new Promise((resolve, reject) =>{

            const query = "UPDATE nstats_matches SET attacking_team=? WHERE id=?";

            mysql.query(query, [team, matchId], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });
    }

    setMatchAssaultCaps(matchId, caps){

        return new Promise((resolve, reject) =>{

            const query = "UPDATE nstats_matches SET assault_caps=? WHERE id=?";

            mysql.query(query, [caps, matchId], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });
    }

    updatePlayerMatchCaps(rowId, caps){

        return new Promise((resolve, reject) =>{

            const query = "UPDATE nstats_player_matches SET assault_objectives=? WHERE id=?";

            mysql.query(query, [caps, rowId], (err) =>{
                
                if(err) reject(err);

                resolve();
            });
        });
    }

    getMatchCaps(matchId){

        return new Promise((resolve, reject) =>{

            const query = "SELECT * FROM nstats_assault_match_objectives WHERE match_id=?";

            mysql.query(query, [matchId], (err, result) =>{

                if(err) reject(err);

                if(result !== undefined){
                    resolve(result);
                }

                resolve([]);
            });
        });
    }

    getMapObjectives(mapId){

        return new Promise((resolve, reject) =>{

            const query = "SELECT DISTINCT * FROM nstats_assault_objects WHERE map=? GROUP BY(obj_id) ORDER BY obj_order ASC";

            mysql.query(query, [mapId], (err, result) =>{

                if(err) reject(err);

                if(result !== undefined){
                    resolve(result);
                }

                resolve([]);
            });
        });
    }


    async getMatchData(matchId, mapId){

        try{

            const mapObjectives = await this.getMapObjectives(mapId);
            const caps = await this.getMatchCaps(matchId);


            return {"objectives": mapObjectives, "caps": caps};

        }catch(err){
            console.trace(err);
        }
    }




    async getMapImages(mapName){

        try{

            mapName = mapName.toLowerCase();

            mapName = mapName.replace(/\W\S\D/ig,'');
            console.log(`mapName = ${mapName}`);
            const dir = fs.readdirSync(`public/images/assault/`);

            console.log(dir);

            if(dir.indexOf(mapName) !== undefined){

                const files = fs.readdirSync(`public/images/assault/${mapName}`);

                console.log(files);

                for(let i = 0; i < files.length; i++){
                    files[i] = `/images/assault/${mapName}/${files[i]}`;
                }

                console.table(files);

                return files;

            }else{
                return [];
            }

        }catch(err){

            if(err.code !== "ENOENT"){
                console.trace(err);
            }else{
                console.log("Assault object folder does not exist");
            }
            return [];
        }   
    }

    deleteMatchObjectives(id){

        return new Promise((resolve, reject) =>{

            const query = "DELETE FROM nstats_assault_match_objectives WHERE match_id=?";

            mysql.query(query, [id], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });

    }


    removeMatchCap(match, obj){

        return new Promise((resolve, reject) =>{

            const query = "UPDATE nstats_assault_objects SET matches=matches-1,taken=taken-1 AND id=?";

            mysql.query(query, [obj], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });
    }

    async deleteMatch(id){

        try{

            const matchCaps = await this.getMatchCaps(id);

            if(matchCaps.length === 0) return;
            
            console.log("Deleteing Assault Match Objectives");

            await this.deleteMatchObjectives(id);

            for(let i = 0; i < matchCaps; i++){

                await this.removeMatchCap(id, matchCaps[i].id);
            }

        }catch(err){

            console.trace(err);
        }   
    }


    deletePlayerMatchCaps(playerId, matchId){

        return new Promise((resolve, reject) =>{

            const query = "UPDATE nstats_assault_match_objectives SET player=-1 WHERE player=? AND match_id=?";

            mysql.query(query, [playerId, matchId], (err) =>{

                if(err) reject(err);

                resolve();
            });
        });
    }

    getPlayerCaps(playerId, matchId){

        return new Promise((resolve, reject) =>{

            const query = "SELECT * FROM nstats_assault_match_objectives WHERE match_id=? AND player=?";

            mysql.query(query, [matchId, playerId], (err, result) =>{

                if(err) reject(err);

                if(result !== undefined){
                    resolve(result);
                }

                resolve([]);
            });
        });
    }

    async deletePlayerFromMatch(playerId, matchId){

        try{

            const capturedObjectives = await this.getPlayerCaps(playerId, matchId);

            console.table(capturedObjectives);

            if(capturedObjectives.length > 0){

                let c = 0;

                for(let i = 0; i < capturedObjectives.length; i++){

                    c = capturedObjectives[i];

                    await this.removeMatchCap(matchId, c.obj_id);
                }

                await this.deletePlayerMatchCaps(playerId, matchId);
            }


        }catch(err){
            console.trace(err);
        }
    }

    

    async changeCapDataPlayerId(oldId, newId){


        await mysql.simpleUpdate("UPDATE nstats_assault_match_objectives SET player=? WHERE player=?", [newId, oldId]);
    }


    /**
     * 
     * @param {*} playerId player to delete
     * @param {*} bReallyDelete if set delete data from database instead of settings playerId to -1
     */
    async deletePlayer(playerId, bReallyDelete){

        if(bReallyDelete !== undefined){
            await mysql.simpleDelete("DELETE FROM nstats_assault_match_objectives WHERE player=?", [playerId]);
        }else{
            await mysql.simpleUpdate("UPDATE nstats_assault_match_objectives SET player=-1 WHERE player=?", [playerId]);
        }
    }


    async getMatchesObjectiveCaps(ids){

        if(ids.length === 0) return [];

        return await mysql.simpleFetch("SELECT * FROM nstats_assault_match_objectives WHERE match_id IN (?)", [ids]);
    }

    setMapObjCaps(objCaps){

        const caps = {};

        let o = 0;
        
        for(let i = 0; i < objCaps.length; i++){

            o = objCaps[i];



            if(caps[o.map] === undefined){
                caps[o.map] = {};
            }

            if(caps[o.map][o.obj_id] === undefined){
                caps[o.map][o.obj_id] = 0;
            }

            caps[o.map][o.obj_id]++;
        }

        return caps;
    }

    async reduceMapObjectiveCaps(map, objId, uses, matches){

        const query = "UPDATE nstats_assault_objects SET matches=matches-?,taken=taken-? WHERE map=? AND obj_id=?";
        const vars = [matches, uses, map, objId];
        await mysql.simpleUpdate(query, vars);
    }

    async deleteMatchesCaps(ids){

        if(ids.length === 0) return;

        await mysql.simpleDelete("DELETE FROM nstats_assault_match_objectives WHERE match_id IN (?)", [ids]);
    }

    async deleteMatches(ids){

        try{

            if(ids.length === 0) return;

            const query = "DELETE FROM nstats_assault_match_objectives WHERE match_id IN(?)";

            //await mysql.simpleDelete(query, [ids]);
            const objCaps = await this.getMatchesObjectiveCaps(ids);

            const mapCaps = this.setMapObjCaps(objCaps);


            for(const [mapId, ObjIds] of Object.entries(mapCaps)){

                for(const [objId, caps] of Object.entries(ObjIds)){

                    await this.reduceMapObjectiveCaps(mapId, objId, caps, caps);
                }

            }

            await this.deleteMatchesCaps(ids);

        }catch(err){
            console.trace(err);
        }
    }


    async getPlayerMatchCaps(matchId, playerId){

        const query = "SELECT timestamp,obj_id,bFinal FROM nstats_assault_match_objectives WHERE match_id=? AND player=?";

        return await mysql.simpleFetch(query, [matchId, playerId]);
    }
}

module.exports = Assault;