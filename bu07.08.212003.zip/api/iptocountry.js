class IPToCountry{

    constructor(){
        console.log("new ip to country");
    }
}


module.exports = IpToCountry;